import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:llamadart/llamadart.dart';

void main() => runApp(const YarAiApp());

class YarAiApp extends StatelessWidget {
  const YarAiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Yar AI Offline',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF287A68)),
          useMaterial3: true,
        ),
        supportedLocales: const [Locale('fa'), Locale('en')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: const ChatScreen(),
      );
}

class ChatMessage {
  final String text;
  final bool fromUser;
  final DateTime createdAt;
  ChatMessage({required this.text, required this.fromUser, required this.createdAt});
  Map<String, dynamic> toJson() => {
        'text': text,
        'fromUser': fromUser,
        'createdAt': createdAt.toIso8601String(),
      };
  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
        text: json['text'] as String,
        fromUser: json['fromUser'] as bool,
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}

/// Loads the quantized Qwen GGUF to the app's private cache on first use.
/// Once cached, inference runs on-device and does not require internet.
class LocalQwen {
  LlamaEngine? _engine;
  ChatSession? _session;

  bool get isLoaded => _session != null;

  Future<void> load({required void Function(double?) onProgress}) async {
    if (_session != null) return;
    final engine = await LlamaEngine.load(
      LlamaModel(
        ModelSource.parse(
          'hf://tensorblock/Qwen_Qwen3-0.6B-GGUF/Qwen3-0.6B-Q4_K_M.gguf',
        ),
      ),
      params: const ModelParams(contextSize: 2048, gpuLayers: 0),
      onProgress: (progress) => onProgress(progress.fraction),
    );
    _engine = engine;
    _session = ChatSession(
      engine,
      maxContextTokens: 1800,
      systemPrompt: 'You are Yar AI, a helpful, respectful assistant. Reply in the language the user uses. For Persian, use clear Afghan Dari wording when appropriate. Give a balanced, useful answer, not too short or too long. Do not claim internet access; you run locally.',
    );
  }

  Future<String> reply(String prompt) async {
    final session = _session;
    if (session == null) throw StateError('Qwen model is not loaded.');
    final response = await session.send(prompt);
    return response.text.trim();
  }

  Future<void> dispose() async {
    _session = null;
    final engine = _engine;
    _engine = null;
    await engine?.dispose();
  }
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _controller = TextEditingController();
  final _scrollController = ScrollController();
  final _messages = <ChatMessage>[];
  final _qwen = LocalQwen();
  bool _isEnglish = false;
  bool _isBusy = false;
  bool _modelReady = false;
  bool _loadingModel = false;
  double? _downloadProgress;
  String? _modelError;

  String get _hello => _isEnglish
      ? 'Hello! I am Yar AI. Ask me anything.'
      : 'سلام! من یار هوش مصنوعی هستم. هر سوالی داری بپرس.';

  @override
  void initState() {
    super.initState();
    _loadMessages();
    _prepareModel();
  }

  Future<void> _prepareModel() async {
    if (_loadingModel || _modelReady) return;
    setState(() {
      _loadingModel = true;
      _modelError = null;
    });
    try {
      await _qwen.load(onProgress: (progress) {
        if (mounted) setState(() => _downloadProgress = progress);
      });
      if (!mounted) return;
      setState(() {
        _modelReady = true;
        _loadingModel = false;
        _downloadProgress = 1;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loadingModel = false;
        _modelError = error.toString();
      });
    }
  }

  Future<void> _loadMessages() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('chat_messages');
    if (raw == null) return;
    try {
      final list = (jsonDecode(raw) as List)
          .map((e) => ChatMessage.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      final cutoff = DateTime.now().subtract(const Duration(hours: 24));
      list.removeWhere((message) => message.createdAt.isBefore(cutoff));
      if (!mounted) return;
      setState(() => _messages.addAll(list));
      await _saveMessages();
    } catch (_) {
      await prefs.remove('chat_messages');
    }
  }

  Future<void> _saveMessages() async {
    final prefs = await SharedPreferences.getInstance();
    final cutoff = DateTime.now().subtract(const Duration(hours: 24));
    _messages.removeWhere((message) => message.createdAt.isBefore(cutoff));
    await prefs.setString(
      'chat_messages',
      jsonEncode(_messages.map((e) => e.toJson()).toList()),
    );
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _isBusy) return;
    if (!_modelReady) {
      if (_modelError != null) await _prepareModel();
      if (!_modelReady) return;
    }
    setState(() {
      _messages.add(ChatMessage(text: text, fromUser: true, createdAt: DateTime.now()));
      _controller.clear();
      _isBusy = true;
    });
    await _saveMessages();
    try {
      final answer = await _qwen.reply(text);
      if (!mounted) return;
      setState(() => _messages.add(ChatMessage(
            text: answer.isEmpty
                ? (_isEnglish ? 'I could not generate a reply. Please try again.' : 'پاسخی ساخته نشد. لطفاً دوباره کوشش کن.')
                : answer,
            fromUser: false,
            createdAt: DateTime.now(),
          )));
    } catch (error) {
      if (!mounted) return;
      setState(() => _messages.add(ChatMessage(
            text: _isEnglish
                ? 'The local model could not answer. Try restarting the app. Details: $error'
                : 'مدل محلی نتوانست پاسخ بدهد. برنامه را دوباره باز کن. جزئیات: $error',
            fromUser: false,
            createdAt: DateTime.now(),
          )));
    } finally {
      if (mounted) setState(() => _isBusy = false);
      await _saveMessages();
      if (_scrollController.hasClients) {
        await _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    unawaited(_qwen.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isRtl = !_isEnglish;
    return Directionality(
      textDirection: isRtl ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Yar AI Offline'),
          actions: [
            TextButton(
              onPressed: () => setState(() => _isEnglish = !_isEnglish),
              child: Text(_isEnglish ? 'دری' : 'English'),
            ),
            IconButton(
              tooltip: _isEnglish ? 'Clear chat' : 'پاک‌کردن گفتگو',
              onPressed: () async {
                setState(_messages.clear);
                _qwen._session?.reset();
                await _saveMessages();
              },
              icon: const Icon(Icons.delete_outline),
            ),
          ],
        ),
        body: Column(children: [
          if (!_modelReady)
            Material(
              color: Theme.of(context).colorScheme.surfaceContainerHighest,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Text(_modelError != null
                      ? (_isEnglish ? 'Model download/load failed.' : 'دانلود یا بارگذاری مدل ناکام شد.')
                      : (_isEnglish ? 'Preparing Qwen AI model…' : 'در حال آماده‌سازی مدل هوش مصنوعی Qwen…')),
                  if (_loadingModel) LinearProgressIndicator(value: _downloadProgress),
                  if (_modelError != null)
                    Align(
                      alignment: AlignmentDirectional.centerEnd,
                      child: TextButton(onPressed: _prepareModel, child: Text(_isEnglish ? 'Retry' : 'دوباره کوشش')),
                    ),
                  Text(
                    _isEnglish
                        ? 'The first download needs internet (about 0.5 GB). After it is stored, chat works offline.'
                        : 'بار اول انترنت ضرورت است (حدود ۰.۵ گیگابایت). پس از ذخیره شدن مدل، چت آفلاین کار می‌کند.',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ]),
              ),
            ),
          Expanded(
            child: _messages.isEmpty
                ? Center(child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(_hello, textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
                  ))
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.all(12),
                    itemCount: _messages.length,
                    itemBuilder: (context, index) {
                      final message = _messages[index];
                      return Align(
                        alignment: message.fromUser ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
                        child: Container(
                          constraints: const BoxConstraints(maxWidth: 340),
                          margin: const EdgeInsets.symmetric(vertical: 5),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: message.fromUser
                                ? Theme.of(context).colorScheme.primaryContainer
                                : Theme.of(context).colorScheme.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Text(message.text),
                        ),
                      );
                    },
                  ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
              child: Row(children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    minLines: 1,
                    maxLines: 5,
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _send(),
                    decoration: InputDecoration(
                      hintText: _isEnglish ? 'Write a message…' : 'پیامت را بنویس…',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  onPressed: (_isBusy || !_modelReady) ? null : _send,
                  icon: _isBusy
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.send),
                ),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}
